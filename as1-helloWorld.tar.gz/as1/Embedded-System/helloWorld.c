#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    printf("Hello embedded world, from Hong!\n");
    return 0;
}